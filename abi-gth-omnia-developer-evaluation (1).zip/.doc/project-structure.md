[Back to README](../README.md)

## Project Structure

The project should be structured as follows:

```
root
├── src/
├── tests/
└── README.md
```
